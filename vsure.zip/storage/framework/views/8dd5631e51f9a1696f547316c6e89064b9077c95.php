<?php echo $__env->make('Includes.adminHeader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make($view, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('Includes.adminFooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>