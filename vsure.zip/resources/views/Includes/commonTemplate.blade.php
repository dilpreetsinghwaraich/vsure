@include('Includes.header')

@include($view)

@include('Includes.footer')