@include('Includes.adminHeader')

@include($view)

@include('Includes.adminFooter')