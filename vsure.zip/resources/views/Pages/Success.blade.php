<div class="header">
  <div class="bg-color" style="background: url('<?php echo asset('/public'); ?>/images/home-back.jpg')">
    <div class="wrapper">
      <div class="banner-info thanku-page-banner banners-home wow fadeIn delay-05s animated" style="visibility: visible; animation-name: fadeIn;">
         <h1 class="bnr-title  text-center gallery">Thank You</h1>
      </div>
    </div>
  </div>
</div>
<section id="feature" class="thanks-page-content section-padding wow fadeIn delay-05s animated" style="visibility: visible; animation-name: fadeIn;">
  <div class="container">
    <div class="text-center">
        <p class="text-center"><img src="<?php echo asset('/public'); ?>/images/thanks.png"></p>
        <h3>Thank You</h3>
        <h2>Your Payment has been transfered Sucessfully!!</h2>
        <a href ="<?php echo url('/') ?>"> Back To Home</a>
      </div>
  </div>
</section>