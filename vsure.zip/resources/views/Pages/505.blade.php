<div class="header">
  <div class="bg-color" style="background: url('<?php echo asset('/public'); ?>/images/home-back.jpg')">
    <div class="wrapper">
      <div class="banner-info thanku-page-banner banners-home wow fadeIn delay-05s animated" style="visibility: visible; animation-name: fadeIn;">
         <h1 class="bnr-title  text-center gallery">500 Error</h1>
      </div>
    </div>
  </div>
</div>
<!--/ HEADER--> 
<section id="feature" class="thanks-page-content section-padding wow fadeIn delay-05s animated" style="visibility: visible; animation-name: fadeIn;">
  <div class="container">
    <div class="text-center">
       <div class="error-page">
         <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 botom">
              <p class="text-center"><img src="<?php echo asset('/public'); ?>/images/planes.png"></p>
              <h2>500 Error Found</h2>
              <p>We’re  Sorry!! This page had a rough landing</p>
              <a href ="<?php echo url('/') ?>"> Back To Home</a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 botom">
              <p class="text-center"><img src="<?php echo asset('/public'); ?>/images/person.png"></p>
          </div>
        </div>
      </div>           
    </div>
  </div>
</section>